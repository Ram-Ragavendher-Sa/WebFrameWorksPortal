package com.example.day1cw2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day1cw2Application {

	public static void main(String[] args) {
		SpringApplication.run(Day1cw2Application.class, args);
	}

}
