package com.example.day6cw1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day6cw1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
